from flask import Flask, render_template, request

app = Flask(__name__)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/arguments')
def arguments():
    return render_template('arguments.html')

@app.route('/about')
def about():
    return render_template('about.html')

@app.route('/quiz', methods=['POST'])
def quiz():
    answers = {
        "question1": "солнечная энергия",
        "question2": "переработка отходов",
        "question3": "электрический автомобиль",
        "question4": "разделение мусора"
    }

    correct = 0
    for q, correct_answer in answers.items():
        if request.form.get(q) == correct_answer:
            correct += 1

    return render_template('results.html', correct_answers=correct)

if __name__ == "__main__":
    app.run(debug=True)
